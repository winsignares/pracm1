import 'package:flutter/material.dart';
import 'package:hola_mundo/Screens/MyApp.dart';


void main() {
  runApp(const MyApp());
}


