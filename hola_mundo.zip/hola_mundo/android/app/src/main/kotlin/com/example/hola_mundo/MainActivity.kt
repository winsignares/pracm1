package com.example.hola_mundo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
